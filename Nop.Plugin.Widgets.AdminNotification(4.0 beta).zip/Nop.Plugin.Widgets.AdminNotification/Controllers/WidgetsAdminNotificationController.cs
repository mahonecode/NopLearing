﻿using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.Widgets.AdminNotification.Models;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Security;
using Nop.Services.Stores;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;

namespace Nop.Plugin.Widgets.AdminNotification.Controllers
{
    [Area(AreaNames.Admin)]
    public class WidgetsAdminNotificationController : BasePluginController
    {
        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly IStoreService _storeService;
        private readonly IPermissionService _permissionService;
        private readonly ISettingService _settingService;
        private readonly ILocalizationService _localizationService;

        public WidgetsAdminNotificationController(IWorkContext workContext,
            IStoreContext storeContext,
            IStoreService storeService,
            IPermissionService permissionService,
            ISettingService settingService,
            ILocalizationService localizationService)
        {
            _workContext = workContext;
            _storeContext = storeContext;
            _storeService = storeService;
            _permissionService = permissionService;
            _settingService = settingService;
            _localizationService = localizationService;
        }

        public IActionResult Configure()
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageWidgets))
                return AccessDeniedView();

            //load settings for a chosen store scope
            var storeScope = GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var adminNotificationSettings = _settingService.LoadSetting<AdminNotificationSettings>(storeScope);

            var model = new ConfigurationModel
            {
                CssConfigurationString = adminNotificationSettings.CssConfigurationString,
                JsConfigurationString = adminNotificationSettings.JsConfigurationString
            };

            if (storeScope > 0)
            {
                model.CssConfigurationStringOverrideForStore = _settingService.SettingExists(adminNotificationSettings, x => x.CssConfigurationString, storeScope);
                model.JsConfigurationStringOverrideForStore = _settingService.SettingExists(adminNotificationSettings, x => x.JsConfigurationString, storeScope);
            }

            return View("~/Plugins/Widgets.AdminNotification/Views/Configure.cshtml", model);
        }

        [HttpPost]
        public IActionResult Configure(ConfigurationModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageWidgets))
                return AccessDeniedView();

            //load settings for a chosen store scope
            var storeScope = GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var adminNotificationSettings = _settingService.LoadSetting<AdminNotificationSettings>(storeScope);

            adminNotificationSettings.CssConfigurationString = model.CssConfigurationString;
            adminNotificationSettings.JsConfigurationString = model.JsConfigurationString;

            /* We do not clear cache after each setting update.
             * This behavior can increase performance because cached settings will not be cleared 
             * and loaded from database after each update */
            _settingService.SaveSettingOverridablePerStore(adminNotificationSettings, x => x.CssConfigurationString, model.CssConfigurationStringOverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(adminNotificationSettings, x => x.JsConfigurationString, model.JsConfigurationStringOverrideForStore, storeScope, false);

            _settingService.ClearCache();

            SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"));
            return Configure();
        }
    }
}
