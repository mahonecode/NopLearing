﻿using Nop.Core.Configuration;

namespace Nop.Plugin.Widgets.AdminNotification
{
    public class AdminNotificationSettings : ISettings
    {
        public string CssConfigurationString { get; set; }
        public string JsConfigurationString { get; set; }
    }
}
