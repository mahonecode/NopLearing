﻿using System.Collections.Generic;
using Nop.Core;
using Nop.Core.Plugins;
using Nop.Services.Cms;
using Nop.Services.Localization;
using Nop.Services.Configuration;

namespace Nop.Plugin.Widgets.AdminNotification
{
    public class AdminNotificationPlugin : BasePlugin, IWidgetPlugin
    {
        private readonly IWebHelper _webHelper;
        private readonly ISettingService _settingService;

        public AdminNotificationPlugin(IWebHelper webHelper, ISettingService settingService)
        {
            _webHelper = webHelper;
            _settingService = settingService;
        }

        public IList<string> GetWidgetZones()
        {
            return new List<string> { "plugin_notifications" };
        }

        public override string GetConfigurationPageUrl()
        {
            return _webHelper.GetStoreLocation() + "Admin/WidgetsAdminNotification/Configure";
        }

        public void GetPublicViewComponent(string widgetZone, out string viewComponentName)
        {
            viewComponentName = "WidgetsAdminNotification";
        }

        public override void Install()
        {
            var settings = new AdminNotificationSettings
            {
                CssConfigurationString = "",
                JsConfigurationString = ""
            };
            _settingService.SaveSetting(settings);

            this.AddOrUpdatePluginLocaleResource("Plugins.Widgets.AdminNotification.CssConfigurationString", "Css Path Configuration");
            this.AddOrUpdatePluginLocaleResource("Plugins.Widgets.AdminNotification.CssConfigurationString.Hint", "Please configure your css path");
            this.AddOrUpdatePluginLocaleResource("Plugins.Widgets.AdminNotification.JsConfigurationString", "Js Path Configuration");
            this.AddOrUpdatePluginLocaleResource("Plugins.Widgets.AdminNotification.JsConfigurationString.Hint", "Please configure your js path");

            base.Install();
        }

        public override void Uninstall()
        {
            _settingService.DeleteSetting<AdminNotificationSettings>();

            this.DeletePluginLocaleResource("Plugins.Widgets.AdminNotification.CssConfigurationString");
            this.DeletePluginLocaleResource("Plugins.Widgets.AdminNotification.CssConfigurationString.Hint");
            this.DeletePluginLocaleResource("Plugins.Widgets.AdminNotification.JsConfigurationString");
            this.DeletePluginLocaleResource("Plugins.Widgets.AdminNotification.JsConfigurationString.Hint");

            base.Uninstall();
        }
    }
}
