﻿using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.Widgets.AdminNotification.Models;
using Nop.Services.Configuration;
using Nop.Web.Framework.Components;

namespace Nop.Plugin.Widgets.AdminNotification.Components
{
    [ViewComponent(Name = "WidgetsAdminNotification")]
    public class WidgetsAdminNotificationViewComponent : NopViewComponent
    {
        private readonly ISettingService _settingService;
        private readonly IStoreContext _storeContext;

        public WidgetsAdminNotificationViewComponent(ISettingService settingService, IStoreContext storeContext)
        {
            _settingService = settingService;
            _storeContext = storeContext;
        }

        public IViewComponentResult Invoke(string widgetZone, object additionalData)
        {
            var adminNotificationSettings = _settingService.LoadSetting<AdminNotificationSettings>(_storeContext.CurrentStore.Id);

            var model = new PublicInfoModel();

            if (!string.IsNullOrEmpty(adminNotificationSettings.CssConfigurationString))
            {
                foreach (var item in adminNotificationSettings.CssConfigurationString.Split(','))
                {
                    model.CssConfigurationList.Add(item);
                }
            }

            if (!string.IsNullOrEmpty(adminNotificationSettings.JsConfigurationString))
            {
                foreach (var item in adminNotificationSettings.JsConfigurationString.Split(','))
                {
                    model.JsConfigurationList.Add(item);
                }
            }

            return View("~/Plugins/Widgets.AdminNotification/Views/PublicInfo.cshtml", model);
        }
    }
}
