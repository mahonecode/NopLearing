﻿using System.Collections.Generic;
using Nop.Web.Framework.Mvc.Models;

namespace Nop.Plugin.Widgets.AdminNotification.Models
{
    public class PublicInfoModel : BaseNopModel
    {
        public PublicInfoModel()
        {
            CssConfigurationList = new List<string>();
            JsConfigurationList = new List<string>();
        }

        public IList<string> CssConfigurationList { get; set; }
        public IList<string> JsConfigurationList { get; set; }
    }
}
