﻿using Nop.Web.Framework.Mvc.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.Widgets.AdminNotification.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        public int ActiveStoreScopeConfiguration { get; set; }

        [NopResourceDisplayName("Plugins.Widgets.AdminNotification.CssConfigurationString")]
        public string CssConfigurationString { get; set; }
        public bool CssConfigurationStringOverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Widgets.AdminNotification.JsConfigurationString")]
        public string JsConfigurationString { get; set; }
        public bool JsConfigurationStringOverrideForStore { get; set; }
    }
}
