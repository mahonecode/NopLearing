﻿using Nop.Web.Framework.Mvc;

namespace Nop.Plugin.Payments.Chinabank.Models
{
    public class PaymentInfoModel : BaseNopModel
    {
    }
}