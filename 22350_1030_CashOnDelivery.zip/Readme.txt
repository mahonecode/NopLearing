1. 'Nop.Plugin.Payments.CashOnDelivery' directory contains source code.
2. 'Payments.CashOnDelivery' contains binaries. Just drop it into \Plugins directory on your server.