﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace Nop.Plugin.Shipping.EMS
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            routes.MapRoute("Plugin.Shipping.EMS.SaveGeneralSettings",
                 "Plugins/ShippingEMS/SaveGeneralSettings",
                 new { controller = "ShippingEMS", action = "SaveGeneralSettings", },
                 new[] { "Nop.Plugin.Shipping.EMS.Controllers" }
            );

            routes.MapRoute("Plugin.Shipping.EMS.AddPopup",
                 "Plugins/ShippingEMS/AddPopup",
                 new { controller = "ShippingEMS", action = "AddPopup" },
                 new[] { "Nop.Plugin.Shipping.EMS.Controllers" }
            );
            routes.MapRoute("Plugin.Shipping.EMS.EditPopup",
                 "Plugins/ShippingEMS/EditPopup",
                 new { controller = "ShippingEMS", action = "EditPopup" },
                 new[] { "Nop.Plugin.Shipping.EMS.Controllers" }
            );
        }
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
