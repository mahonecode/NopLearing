﻿using System;
using System.Web.Routing;
using Nop.Core;
using Nop.Core.Domain.Shipping;
using Nop.Core.Plugins;
using Nop.Plugin.Shipping.EMS.Data;
using Nop.Plugin.Shipping.EMS.Services;
using Nop.Services.Catalog;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Shipping;
using Nop.Services.Shipping.Tracking;

namespace Nop.Plugin.Shipping.EMS
{
    public class EMSShippingComputationMethod : BasePlugin, IShippingRateComputationMethod
    {
        #region Fields

        private readonly IShippingService _shippingService;
        private readonly IStoreContext _storeContext;
        private readonly IShippingEMSService _shippingEMSService;
        private readonly IPriceCalculationService _priceCalculationService;
        private readonly ShippingEMSObjectContext _objectContext;
        private readonly ISettingService _settingService;

        #endregion

        #region Ctor
        public EMSShippingComputationMethod(IShippingService shippingService,
            IStoreContext storeContext,
            IShippingEMSService shippingEMSService,
            IPriceCalculationService priceCalculationService,
           ShippingEMSObjectContext objectContext,
            ISettingService settingService)
        {
            this._shippingService = shippingService;
            this._storeContext = storeContext;
            this._shippingEMSService = shippingEMSService;
            this._priceCalculationService = priceCalculationService;
            this._objectContext = objectContext;
            this._settingService = settingService;
        }
        #endregion

        #region Utilities
        /// <summary>
        /// 运费计算公式
        /// </summary>
      
        public  decimal? GetRate(decimal weight,  int stateProvinceId)
        {
            var shippingEMSRecord = _shippingEMSService.FindRecord(stateProvinceId);
            if (shippingEMSRecord == null)
            {
               return decimal.Zero;
            }

           
            decimal withinTheHalfKilogramCost = shippingEMSRecord.WithinTheHalfKilogramCost;    //500克以内的运费
            decimal withinTheOneKilogramCost = shippingEMSRecord.WithinTheOneKilogramCost;       //1000克以内的运费
            decimal morethanPerHalfKilogramCost = shippingEMSRecord.MorethanPerHalfKilogramCost;  //超过1000克的每500克的运费
            decimal shippingTotal = decimal.Zero;
            weight = weight * 1000;
            if (weight <= decimal.Zero)
            {
                shippingTotal = decimal.Zero;
                
            }
            if (weight<=500)
            {
                shippingTotal = withinTheHalfKilogramCost;
               
            }
            if (weight > 500 && weight<=1000)
            {
                shippingTotal = withinTheOneKilogramCost;
               
            }
            if (weight > 1000)
            {
                decimal moreWeight = weight - 1000;
                int Multiple = Decimal.ToInt32(moreWeight / 500);
                decimal Remainder = moreWeight % 500;
                if (Remainder > 0)
                {
                    shippingTotal = Math.Round((decimal)(withinTheOneKilogramCost + (Multiple + 1) * morethanPerHalfKilogramCost), 2);
                }
                else
                {
                    shippingTotal = Math.Round((decimal)(withinTheOneKilogramCost + Multiple * morethanPerHalfKilogramCost), 2);
                }                    
            }
            return shippingTotal;
        }

        #endregion

        #region Methods

        /// <summary>
        ///  Gets available shipping options
        /// </summary>
        /// <param name="getShippingOptionRequest">A request for getting shipping options</param>
        /// <returns>Represents a response of getting shipping rate options</returns>
        public GetShippingOptionResponse GetShippingOptions(GetShippingOptionRequest getShippingOptionRequest)
        {
            if (getShippingOptionRequest == null)
                throw new ArgumentNullException("getShippingOptionRequest");

            var response = new GetShippingOptionResponse();

            if (getShippingOptionRequest.Items == null || getShippingOptionRequest.Items.Count == 0)
            {
                response.AddError("No shipment items");
                return response;
            }
            if (getShippingOptionRequest.ShippingAddress == null)
            {
                response.AddError("Shipping address is not set");
                return response;
            }

            var processor = _shippingService.LoadShippingRateComputationMethodBySystemName("Shipping.EMS");
            if (processor == null || !processor.PluginDescriptor.Installed)
                throw new NopException("PayPal Standard module cannot be loaded");


            var storeId = _storeContext.CurrentStore.Id;
            int stateProvinceId = getShippingOptionRequest.ShippingAddress.StateProvinceId.HasValue ? getShippingOptionRequest.ShippingAddress.StateProvinceId.Value : 0;
            decimal weight = _shippingService.GetTotalWeight(getShippingOptionRequest.Items);


            decimal? rate = GetRate(weight,stateProvinceId);
            if (rate.HasValue)
            {
                var shippingOption = new ShippingOption();
                shippingOption.Name = processor.PluginDescriptor.FriendlyName;
                shippingOption.Description = processor.PluginDescriptor.FriendlyName;
                shippingOption.Rate = rate.Value;
                response.ShippingOptions.Add(shippingOption);
            }


            return response;
        }

        /// <summary>
        /// Gets fixed shipping rate (if shipping rate computation method allows it and the rate can be calculated before checkout).
        /// </summary>
        /// <param name="getShippingOptionRequest">A request for getting shipping options</param>
        /// <returns>Fixed shipping rate; or null in case there's no fixed shipping rate</returns>
        public decimal? GetFixedRate(GetShippingOptionRequest getShippingOptionRequest)
        {
            if (getShippingOptionRequest == null)
                throw new ArgumentNullException("getShippingOptionRequest");

            var response = new GetShippingOptionResponse();

            if (getShippingOptionRequest.Items == null || getShippingOptionRequest.Items.Count == 0)
            {
                response.AddError("No shipment items");
                return null;
            }
            if (getShippingOptionRequest.ShippingAddress == null)
            {
                response.AddError("Shipping address is not set");
                return null;
            }

            var processor = _shippingService.LoadShippingRateComputationMethodBySystemName("Shipping.EMS");
            if (processor == null || !processor.PluginDescriptor.Installed)
                throw new NopException("PayPal Standard module cannot be loaded");


            var storeId = _storeContext.CurrentStore.Id;
            int stateProvinceId = getShippingOptionRequest.ShippingAddress.StateProvinceId.HasValue ? getShippingOptionRequest.ShippingAddress.StateProvinceId.Value : 0;
            decimal weight = _shippingService.GetTotalWeight(getShippingOptionRequest.Items);


            decimal? rate = GetRate(weight, stateProvinceId);
            return rate;
        }

        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "ShippingEMS";
            routeValues = new RouteValueDictionary() { { "Namespaces", "Nop.Plugin.Shipping.EMS.Controllers" }, { "area", null } };
        }

        /// <summary>
        /// Install plugin
        /// </summary>
        public override void Install()
        {
            ////settings
            //var settings = new ShippingEMSSettings()
            //{
            //    LimitMethodsToCreated = false,
            //};
            //_settingService.SaveSetting(settings);


            //database objects
            _objectContext.Install();

            //locales
            this.AddOrUpdatePluginLocaleResource("Plugins.Shipping.EMS.Fields.Store", "商城");
            this.AddOrUpdatePluginLocaleResource("Plugins.Shipping.EMS.Fields.Store.Hint", "如果被选中，则这配送费率将适用于所有商店。");
            this.AddOrUpdatePluginLocaleResource("Plugins.Shipping.EMS.Fields.StateProvince", "省/直辖市");
            this.AddOrUpdatePluginLocaleResource("Plugins.Shipping.EMS.Fields.StateProvince.Hint", "如果选择*星号时,则这配送费率将适用于所有客户指定的省份中。");
            this.AddOrUpdatePluginLocaleResource("Plugins.Shipping.EMS.Fields.Zip", "邮政编码");
            this.AddOrUpdatePluginLocaleResource("Plugins.Shipping.EMS.Fields.Zip.Hint", "邮政编码。如果邮政编码为空,则忽略掉邮政编码从而将配送费应用于所有客户指定的省份中。");
            this.AddOrUpdatePluginLocaleResource("Plugins.Shipping.EMS.Fields.WithinTheOneKilogramCost", "1Kg以内的运费");
            this.AddOrUpdatePluginLocaleResource("Plugins.Shipping.EMS.Fields.WithinTheHalfKilogramCost", "500g以内的运费");
            this.AddOrUpdatePluginLocaleResource("Plugins.Shipping.EMS.Fields.MoreThanPerHalfKilogramCost", "续重每500g的运费");
            this.AddOrUpdatePluginLocaleResource("Plugins.Shipping.EMS.AddRecord", "添加记录");
            base.Install();
        }

        /// <summary>
        /// Uninstall plugin
        /// </summary>
        public override void Uninstall()
        {
            //settings
            //_settingService.DeleteSetting<ShippingEMSSettings>();

            //database objects
            _objectContext.Uninstall();

            //locales
            this.DeletePluginLocaleResource("Plugins.Shipping.EMS.Fields.Store");
            this.DeletePluginLocaleResource("Plugins.Shipping.EMS.Fields.Store.Hint");
            this.DeletePluginLocaleResource("Plugins.Shipping.EMS.Fields.StateProvince");
            this.DeletePluginLocaleResource("Plugins.Shipping.EMS.Fields.StateProvince.Hint");
            this.DeletePluginLocaleResource("Plugins.Shipping.EMS.Fields.Zip");
            this.DeletePluginLocaleResource("Plugins.Shipping.EMS.Fields.Zip.Hint");
            this.DeletePluginLocaleResource("Plugins.Shipping.EMS.Fields.WithinTheOneKilogramCost");
            this.DeletePluginLocaleResource("Plugins.Shipping.EMS.Fields.WithinTheHalfKilogramCost");
            this.DeletePluginLocaleResource("Plugins.Shipping.EMS.Fields.MoreThanPerHalfKilogramCost");
            this.DeletePluginLocaleResource("Plugins.Shipping.EMS.AddRecord");
            base.Uninstall();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets a shipping rate computation method type
        /// </summary>
        public ShippingRateComputationMethodType ShippingRateComputationMethodType
        {
            get
            {
                return ShippingRateComputationMethodType.Offline;
            }
        }


        /// <summary>
        /// Gets a shipment tracker
        /// </summary>
        public IShipmentTracker ShipmentTracker
        {
            get
            {
                return new EmsShipmentTracker();
            }
        }

        #endregion
    }
}
