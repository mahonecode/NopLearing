﻿using Nop.Core.Configuration;

namespace Nop.Plugin.Shipping.EMS
{
    public class EmsSettings : ISettings
    {
        public string TrackingUrl { get; set; }

        public int Port { get; set; }

        public string CustomerId { get; set; }
    }
}