using Nop.Core;

namespace Nop.Plugin.Shipping.EMS.Domain
{
    /// <summary>
    /// Represents a shipping by weight record
    /// </summary>
    public partial class ShippingEMSRecord : BaseEntity
    {
        /// <summary>
        /// Gets or sets the store identifier
        /// </summary>
        public int StoreId { get; set; }
        /// <summary>
        /// Gets or sets the state/province identifier
        /// </summary>
        public int StateProvinceId { get; set; }

        /// <summary>
        /// Gets or sets the zip
        /// </summary>
        public string Zip { get; set; }
        /// <summary>
        /// 500�����ڵ��˷�
        /// </summary>
        public decimal WithinTheHalfKilogramCost { get; set; }

        /// <summary>
        /// 1ǧ�����ڵ��˷�
        /// </summary>
        public decimal WithinTheOneKilogramCost { get; set; }

        /// <summary>
        ///����1ǧ�˺�ÿ500�˵��˷�
        /// </summary>
        public decimal MorethanPerHalfKilogramCost { get; set; }
 }
}