﻿using System.Collections.Generic;
using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace Nop.Plugin.Shipping.EMS.Models
{
    public class ShippingEMSModel : BaseNopEntityModel
    {
        public ShippingEMSModel()
        {
            AvailableStates = new List<SelectListItem>();
            AvailableStores = new List<SelectListItem>();
        }

        [NopResourceDisplayName("Plugins.Shipping.EMS.Fields.Store")]
        public int StoreId { get; set; }
        [NopResourceDisplayName("Plugins.Shipping.EMS.Fields.Store")]
        public string StoreName { get; set; }

       [NopResourceDisplayName("Plugins.Shipping.EMS.Fields.StateProvince")]
        public int StateProvinceId { get; set; }
        [NopResourceDisplayName("Plugins.Shipping.EMS.Fields.StateProvince")]
        public string StateProvinceName { get; set; }

        [NopResourceDisplayName("Plugins.Shipping.EMS.Fields.Zip")]
        public string Zip { get; set; }

     [NopResourceDisplayName("Plugins.Shipping.EMS.Fields.WithinTheHalfKilogramCost")]
        public decimal WithinTheHalfKilogramCost { get; set; }

        [NopResourceDisplayName("Plugins.Shipping.EMS.Fields.WithinTheOneKilogramCost")]
        public decimal WithinTheOneKilogramCost { get; set; }

        [NopResourceDisplayName("Plugins.Shipping.EMS.Fields.MorethanPerHalfKilogramCost")]
        public decimal MorethanPerHalfKilogramCost { get; set; }



   
        public IList<SelectListItem> AvailableStates { get; set; }
    
        public IList<SelectListItem> AvailableStores { get; set; }
    }
}