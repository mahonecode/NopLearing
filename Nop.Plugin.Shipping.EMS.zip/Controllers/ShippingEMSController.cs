﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Nop.Core;
using Nop.Core.Domain.Directory;
using Nop.Plugin.Shipping.EMS.Domain;
using Nop.Plugin.Shipping.EMS.Models;
using Nop.Plugin.Shipping.EMS.Services;
using Nop.Services.Configuration;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Services.Security;
using Nop.Services.Shipping;
using Nop.Services.Stores;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Kendoui;
using Nop.Web.Framework.Mvc;

namespace Nop.Plugin.Shipping.EMS.Controllers
{
    [AdminAuthorize]
    public class ShippingEMSController : BasePluginController
    {
        private readonly IShippingService _shippingService;
        private readonly IStoreService _storeService;
        private readonly ICountryService _countryService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly IShippingEMSService _shippingEMSService;
        private readonly ISettingService _settingService;
        private readonly ILocalizationService _localizationService;
        private readonly IPermissionService _permissionService;

        private readonly ICurrencyService _currencyService;
        private readonly CurrencySettings _currencySettings;
        private readonly IMeasureService _measureService;
        private readonly MeasureSettings _measureSettings;

        public ShippingEMSController(IShippingService shippingService,
            IStoreService storeService, ICountryService countryService, IStateProvinceService stateProvinceService,
           IShippingEMSService shippingEMSService, ISettingService settingService,
            ILocalizationService localizationService, IPermissionService permissionService,
            ICurrencyService currencyService, CurrencySettings currencySettings,
            IMeasureService measureService, MeasureSettings measureSettings)
        {
            this._shippingService = shippingService;
            this._storeService = storeService;
            this._countryService = countryService;
            this._stateProvinceService = stateProvinceService;
            this._shippingEMSService = shippingEMSService;
            this._settingService = settingService;
            this._localizationService = localizationService;
            this._permissionService = permissionService;

            this._currencyService = currencyService;
            this._currencySettings = currencySettings;
            this._measureService = measureService;
            this._measureSettings = measureSettings;
        }
        
        protected override void Initialize(System.Web.Routing.RequestContext requestContext)
        {
            //little hack here
            //always set culture to 'en-US' (Telerik has a bug related to editing decimal values in other cultures). Like currently it's done for admin area in Global.asax.cs
            CommonHelper.SetTelerikCulture();

            base.Initialize(requestContext);
        }

        [ChildActionOnly]
        public ActionResult Configure()
        {
            var model = new ShippingEMSModel();
            return View("Nop.Plugin.Shipping.EMS.Views.ShippingEMS.Configure", model);
        }


        [HttpPost]
        public ActionResult RatesList(DataSourceRequest command)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageShippingSettings))
                return Content("Access denied");

            var records = _shippingEMSService.GetAll(command.Page - 1, command.PageSize);
            var sbwModel = records.Select(x =>
                {
                    var m = new ShippingEMSModel()
                    {
                        Id = x.Id,
                        StoreId = x.StoreId,
                        WithinTheHalfKilogramCost = x.WithinTheHalfKilogramCost,
                        WithinTheOneKilogramCost = x.WithinTheOneKilogramCost,
                        MorethanPerHalfKilogramCost = x.MorethanPerHalfKilogramCost,
                    };
                
                    //store
                    var store = _storeService.GetStoreById(x.StoreId);
                    m.StoreName = (store != null) ? store.Name : "*";
                    //state
                    var s = _stateProvinceService.GetStateProvinceById(x.StateProvinceId);
                    m.StateProvinceName = (s != null) ? s.Name : "*";
                    //zip
                    m.Zip = (!String.IsNullOrEmpty(x.Zip)) ? x.Zip : "*";
                    return m;
                })
                .ToList();
            var gridModel = new DataSourceResult
            {
                Data = sbwModel,
                Total = records.TotalCount
            };

            return Json(gridModel);
        }

        [HttpPost]
        public ActionResult RateDelete(int id)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageShippingSettings))
                return Content("Access denied");

            var sbw = _shippingEMSService.GetById(id);
            if (sbw != null)
                _shippingEMSService.DeleteShippingEMSRecord(sbw);

            return new NullJsonResult();
        }

        //add
        public ActionResult AddPopup()
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageShippingSettings))
                return Content("Access denied");

            var model = new ShippingEMSModel();
           //stores
           foreach (var store in _storeService.GetAllStores())
                model.AvailableStores.Add(new SelectListItem() { Text = store.Name, Value = store.Id.ToString() });
            //states
           model.AvailableStates.Add(new SelectListItem() { Text = "*", Value = "0" });
         foreach (var states in _stateProvinceService.GetStateProvincesByCountryId(21, true)) //21代表中国
             model.AvailableStates.Add(new SelectListItem() { Text = states.Name, Value = states.Id.ToString() });

            return View("Nop.Plugin.Shipping.EMS.Views.ShippingEMS.AddPopup", model);
        }
        [HttpPost]
        public ActionResult AddPopup(string btnId, string formId, ShippingEMSModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageShippingSettings))
                return Content("Access denied");

            var sems = new ShippingEMSRecord()
            {
                StoreId = model.StoreId,
              
                StateProvinceId = model.StateProvinceId,
                Zip = model.Zip == "*" ? null : model.Zip,
                WithinTheHalfKilogramCost = model.WithinTheHalfKilogramCost,
                WithinTheOneKilogramCost = model.WithinTheOneKilogramCost,
                MorethanPerHalfKilogramCost = model.MorethanPerHalfKilogramCost
            };
            _shippingEMSService.InsertShippingEMSRecord(sems);

            ViewBag.RefreshPage = true;
            ViewBag.btnId = btnId;
            ViewBag.formId = formId;
            return View("Nop.Plugin.Shipping.EMS.Views.ShippingEMS.AddPopup", model);
        }

        //edit
        public ActionResult EditPopup(int id)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageShippingSettings))
                return Content("Access denied");

            var sems = _shippingEMSService.GetById(id);
            if (sems == null)
                //No record found with the specified id
                return RedirectToAction("Configure");

            var model = new ShippingEMSModel()
            {
                Id = sems.Id,
                StoreId = sems.StoreId,
                StateProvinceId = sems.StateProvinceId,
                Zip = sems.Zip,
                WithinTheHalfKilogramCost = sems.WithinTheHalfKilogramCost,
                WithinTheOneKilogramCost = sems.WithinTheOneKilogramCost,
                MorethanPerHalfKilogramCost = sems.MorethanPerHalfKilogramCost,
             };

            var selectedStore = _storeService.GetStoreById(sems.StoreId);
            var selectedState = _stateProvinceService.GetStateProvinceById(sems.StateProvinceId);
            //stores
            foreach (var store in _storeService.GetAllStores())
                model.AvailableStores.Add(new SelectListItem() { Text = store.Name, Value = store.Id.ToString(), Selected = (selectedStore != null && store.Id == selectedStore.Id) });
            //states
            var states = _stateProvinceService.GetStateProvincesByCountryId(21, true).ToList();   //21代表中国
            model.AvailableStates.Add(new SelectListItem() { Text = "*", Value = "0" });
            foreach (var s in states)
                model.AvailableStates.Add(new SelectListItem() { Text = s.Name, Value = s.Id.ToString(), Selected = (selectedState != null && s.Id == selectedState.Id) });
            
            return View("Nop.Plugin.Shipping.EMS.Views.ShippingEMS.EditPopup", model);
        }
        [HttpPost]
        public ActionResult EditPopup(string btnId, string formId, ShippingEMSModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageShippingSettings))
                return Content("Access denied");

            var sems = _shippingEMSService.GetById(model.Id);
            if (sems == null)
                //No record found with the specified id
                return RedirectToAction("Configure");

            sems.StoreId = model.StoreId;
            sems.StateProvinceId = model.StateProvinceId;
            sems.Zip = model.Zip == "*" ? null : model.Zip;
            sems.WithinTheHalfKilogramCost = model.WithinTheHalfKilogramCost;
            sems.WithinTheOneKilogramCost = model.WithinTheOneKilogramCost;
            sems.MorethanPerHalfKilogramCost = model.MorethanPerHalfKilogramCost;
            _shippingEMSService.UpdateShippingEMSRecord(sems);

            ViewBag.RefreshPage = true;
            ViewBag.btnId = btnId;
            ViewBag.formId = formId;
            return View("Nop.Plugin.Shipping.EMS.Views.ShippingEMS.EditPopup", model);
        }
    }
}
