using System;
using System.Collections.Generic;
using System.Linq;
using Nop.Core;
using Nop.Core.Caching;
using Nop.Core.Data;
using Nop.Plugin.Shipping.EMS.Domain;

namespace Nop.Plugin.Shipping.EMS.Services
{
    public partial class ShippingEMSService : IShippingEMSService
    {
        #region Constants
        private const string SHIPPINGEMS_ALL_KEY = "Nop.shippingEMS.all-{0}-{1}";
        private const string SHIPPINGEMS_PATTERN_KEY = "Nop.shippingEMS.";
        #endregion

        #region Fields

        private readonly IRepository<ShippingEMSRecord> _sbwRepository;
        private readonly ICacheManager _cacheManager;

        #endregion

        #region Ctor

        public ShippingEMSService(ICacheManager cacheManager,
            IRepository<ShippingEMSRecord> sbwRepository)
        {
            this._cacheManager = cacheManager;
            this._sbwRepository = sbwRepository;
        }

        #endregion

        #region Methods

        
        public virtual void DeleteShippingEMSRecord(ShippingEMSRecord shippingEMSRecord)
        {
            if (shippingEMSRecord == null)
                throw new ArgumentNullException("shippingEMSRecord");

            _sbwRepository.Delete(shippingEMSRecord);

            _cacheManager.RemoveByPattern(SHIPPINGEMS_PATTERN_KEY);
        }

        public virtual IPagedList<ShippingEMSRecord> GetAll(int pageIndex = 0, int pageSize = int.MaxValue)
        {
            string key = string.Format(SHIPPINGEMS_ALL_KEY, pageIndex, pageSize);
            return _cacheManager.Get(key, () =>
            {
                var query = from sems in _sbwRepository.Table
                            orderby sems.StoreId, sems.StateProvinceId, sems.Zip
                            select sems;

                var records = new PagedList<ShippingEMSRecord>(query, pageIndex, pageSize);
                return records;
            });
        }

        public virtual ShippingEMSRecord FindRecord(int stateProvinceId)
        {
            
            var existingRates = GetAll();
             
            //filter by state/province
            var matchedByStateProvince = new List<ShippingEMSRecord>();
            foreach (var sems in existingRates)
                if (stateProvinceId == sems.StateProvinceId)
                    matchedByStateProvince.Add(sems);
            if (matchedByStateProvince.Count == 0)
                foreach (var sems in existingRates)
                    if (sems.StateProvinceId == 0)
                        matchedByStateProvince.Add(sems);



            return matchedByStateProvince.FirstOrDefault();
        }

        public virtual ShippingEMSRecord GetById(int shippingEMSRecordId)
        {
            if (shippingEMSRecordId == 0)
                return null;

            return _sbwRepository.GetById(shippingEMSRecordId);
        }

        public virtual void InsertShippingEMSRecord(ShippingEMSRecord shippingEMSRecord)
        {
            if (shippingEMSRecord == null)
                throw new ArgumentNullException("shippingEMSRecord");

            _sbwRepository.Insert(shippingEMSRecord);

            _cacheManager.RemoveByPattern(SHIPPINGEMS_PATTERN_KEY);
        }

        public virtual void UpdateShippingEMSRecord(ShippingEMSRecord shippingEMSRecord)
        {
            if (shippingEMSRecord == null)
                throw new ArgumentNullException("shippingEMSRecord");

            _sbwRepository.Update(shippingEMSRecord);

            _cacheManager.RemoveByPattern(SHIPPINGEMS_PATTERN_KEY);
        }

        #endregion
    }
}
