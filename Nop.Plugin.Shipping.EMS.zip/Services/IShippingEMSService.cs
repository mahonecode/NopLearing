using Nop.Core;
using Nop.Plugin.Shipping.EMS.Domain;

namespace Nop.Plugin.Shipping.EMS.Services
{
    public partial interface IShippingEMSService
    {
        void DeleteShippingEMSRecord(ShippingEMSRecord shippingEMSRecord);

        IPagedList<ShippingEMSRecord> GetAll(int pageIndex = 0, int pageSize = int.MaxValue);

        ShippingEMSRecord FindRecord(int stateProvinceId);

        ShippingEMSRecord GetById(int shippingEMSRecordId);

        void InsertShippingEMSRecord(ShippingEMSRecord shippingEMSRecord);

        void UpdateShippingEMSRecord(ShippingEMSRecord shippingEMSRecord);
    }
}
