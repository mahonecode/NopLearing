using System.Data.Entity.ModelConfiguration;
using Nop.Plugin.Shipping.EMS.Domain;

namespace Nop.Plugin.Shipping.EMS.Data
{
    public partial class ShippingEMSRecordMap : EntityTypeConfiguration<ShippingEMSRecord>
    {
        public ShippingEMSRecordMap()
        {
            this.ToTable("ShippingEMS");
            this.HasKey(x => x.Id);

            this.Property(x => x.Zip).HasMaxLength(400);
        }
    }
}