using Autofac;
using Autofac.Core;
using Autofac.Integration.Mvc;
using Nop.Core.Data;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Nop.Data;
using Nop.Plugin.Shipping.EMS.Data;
using Nop.Plugin.Shipping.EMS.Domain;
using Nop.Plugin.Shipping.EMS.Services;
using Nop.Web.Framework.Mvc;

namespace Nop.Plugin.Shipping.EMS
{
    public class DependencyRegistrar : IDependencyRegistrar
    {
        public virtual void Register(ContainerBuilder builder, ITypeFinder typeFinder)
        {
            builder.RegisterType<ShippingEMSService>().As<IShippingEMSService>().InstancePerRequest();

            //data context
            this.RegisterPluginDataContext<ShippingEMSObjectContext>(builder, "nop_object_context_shipping_ems_zip");

            //override required repository with our custom context
            builder.RegisterType<EfRepository<ShippingEMSRecord>>()
                .As<IRepository<ShippingEMSRecord>>()
                .WithParameter(ResolvedParameter.ForNamed<IDbContext>("nop_object_context_shipping_ems_zip"))
                .InstancePerRequest();
        }

        public int Order
        {
            get { return 1; }
        }
    }
}
